package twelveengine.actors;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.PhysModel;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelveutil.MathUtil;

public class Actor {
	public Game game;
	
	public String file;
	public String name;
	public int nid;
	
	public PhysModel collision;
	
	public boolean dead;
	
	public int team;
	
	public Vertex location;
	public Vertex rotation;
	public Vertex velocity;
	
	public double radius;
	
	//These are used to flag an update
	public boolean netLoc;
	public boolean netRot;
	
	//NEVER INSTANTIATE AN ACTOR MANUALLY / USE engine.game.addObject(); Actor classes are just template for a tag like assets/object/character/generic to fill out and become an object in the world thorugh
	public Actor(Game w, int n) {
		game = w;
		nid = n;
		file = "null";
		name = "null";
		dead = false;
		team = -1;
		location = new Vertex(0,0,0);
		rotation = new Vertex(0,0,0);
		velocity = new Vertex(0,0,0);
		radius = 1;
	}
	
	public void step() {
		
	}
	
	public void netStep(ArrayList<Packet> out) {
		if(netLoc) {
			out.add(new Packet11Location(nid, false, location.x, location.y, location.z, velocity.x, velocity.y, velocity.z));
			netLoc = false;
		}
		if(netRot) {
			out.add(new Packet12Rotation(nid, false, rotation.x, rotation.y, rotation.z));
			netRot = false;
		}
	}
	
	public void move(Vertex a) {
		location = MathUtil.add(location, a);
		netLoc = true;
	}
	
	public void rotate(Vertex a) {
		rotation = MathUtil.add(rotation, a);
		netRot = true;
	}
	
	public void push(Vertex a) {
		velocity = MathUtil.add(velocity, a);
		netLoc = true;
	}
	
	public void setLocation(Vertex a) {
		location = a;
		netLoc = true;
	}
	
	public void setRotation(Vertex a) {
		rotation = a;
		netRot = true;
	}
	
	public void setVelocity(Vertex a) {
		velocity = a;
		netLoc = true;
	}
	
	public void damage(double d, Vertex i, Actor a) {
		
	}
	
	public String getName() {
		return name;
	}
	
	public String toString() {
		return "Actor:" + name + ":" + nid;
	}
	
	public String getType() {
		return "";
	}
	
	public void kill() {
		dead = true;
	}
}
