package twelveengine.actors;

import twelveengine.Game;
import twelveengine.data.Vertex;
import twelveutil.MathUtil;

public class Pawn extends Biped {
	
	public double moveSpeed;
	public double airControl;
	
	public boolean fp = false;
	
	public Pawn(Game w, int n, String p) {
		super(w, n, p);
		
		moveSpeed = 0.7;
		airControl = 0.05;
	}
	
	public void movement(Vertex a) {
		if(onGround) {
			Vertex m = new Vertex(0,0,0);
			m = MathUtil.add(m, moveOnLookX(move, a.x));
			m = MathUtil.add(m, moveOnLookY(move, a.y));
			m = MathUtil.multiply(MathUtil.normalize(m), moveSpeed);
			push(m);
		}
		else {		
			Vertex m = new Vertex(0,0,0);
			m = MathUtil.add(m, moveOnLookX(move, a.x));
			m = MathUtil.add(m, moveOnLookY(move, a.y));
			m = MathUtil.multiply(MathUtil.multiply(MathUtil.normalize(m), moveSpeed), airControl);
			push(m);
		}
	}
	
	public Vertex moveOnLookX(Vertex b, double d) {
		Vertex c = MathUtil.normalize(MathUtil.multiply(b, new Vertex(d,d,d)));
		return c;
	}
	
	public Vertex moveOnLookY(Vertex b, double d) {
		Vertex e = new Vertex(-b.y, b.x, b.z);
		Vertex c = MathUtil.normalize(MathUtil.multiply(e, new Vertex(d,d,d)));
		return c;
	}	
	
	public String getType() {
		return "bp";
	}
}
