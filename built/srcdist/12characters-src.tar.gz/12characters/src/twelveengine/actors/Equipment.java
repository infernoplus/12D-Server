package twelveengine.actors;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelvelib.net.packets.Packet17Equipment;
import twelveutil.MathUtil;

public class Equipment extends Item {
	public String type;
	public boolean stacks;
	
	public String fileCreateOnUse;
	
	public int total;
	
	public double impulse;
	
	//These are used to flag an update
	public boolean netTot;
	
	public Equipment(Game w, int n) {
		super(w, n);
		type = "none";
		stacks = true;
		total = 1;
		impulse = 10;
	}
	
	public void netStep(ArrayList<Packet> out) {
		if(netLoc) {
			out.add(new Packet11Location(nid, false, location.x, location.y, location.z, velocity.x, velocity.y, velocity.z));
			netLoc = false;
		}
		if(netRot) {
			out.add(new Packet12Rotation(nid, false, rotation.x, rotation.y, rotation.z));
			netRot = false;
		}
		if(netTot) {
			out.add(new Packet17Equipment(nid, total));
			netTot = false;
		}
	}
	
	public void useEquipment(Biped b) {
		if(total > 0) {
			game.addObject(fileCreateOnUse, MathUtil.multiply(b.location.copy(), impulse), MathUtil.normalize(b.look.copy()), new Vertex(0,0,0), -1);
			setTotal(total-1);
		}
	}
	
	public void setTotal(int i) {
		total = i;
		netTot = true;
	}
	
	public String equipmentType() {
		return type;
	}
	
	public String getName() {
		return name + ": " + total;
	}
	
	public String toString() {
		return "Equipment:" + name + ":" + nid;
	}
	
	public String getType() {
		return "ie";
	}
}