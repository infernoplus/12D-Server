package twelveengine.actors;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysModel;
import twelveengine.data.Vertex;
import twelveengine.graphics.GraphicsCore;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelvelib.net.packets.Packet13Push;
import twelvelib.net.packets.Packet31Inventory;
import twelvelib.net.packets.Packet34Equip;
import twelvelib.net.packets.Packet42Health;
import twelveutil.MathUtil;

public class Biped extends Actor {
	
	public Vertex move;
	public Vertex look;
	
	public double health;
	public double maxHealth;
	
	public Weapon weapon;
	public Equipment equipment;
	public ArrayList<Item> inventory;
	
	public boolean jumping = false;
	public boolean onGround = false;
	public Collision ground = null;
	
	public double eye;
	public double foot;
	
	public double jumpHeight;
	
	public Actor attacker = null;
	
	//These are used to flag an update
	public boolean netInv;
	
	public Biped(Game w, int n, String p) {
		super(w, n);
		collision = new PhysModel(location, 1.0, p);
		
		move = new Vertex(0, 1, 0);
		look = new Vertex(0, 1, 0);
		
		maxHealth = 100;
		health = maxHealth;
		
		foot = 4;
		eye = 3;
		jumpHeight = 1.5;
		
		weapon = null;
		inventory = new ArrayList<Item>();
	}
	
	public void step() {
		look();
		move();
		collision();
		inventory();
		equipment();
		health();
	}
	
	public void netStep(ArrayList<Packet> out) {
		if(netLoc) {
			out.add(new Packet11Location(nid, false, location.x, location.y, location.z, velocity.x, velocity.y, velocity.z));
			netLoc = false;
		}
		if(netRot) {
			out.add(new Packet12Rotation(nid, false, rotation.x, rotation.y, rotation.z));
			netRot = false;
		}
		
		int invUpd[] = new int[inventory.size()];
		int i = 0;
		while(i < invUpd.length) {
			invUpd[i] = inventory.get(i).nid;
			i++;
		}
		
		if(netInv) {
			out.add(new Packet31Inventory(nid, invUpd));
			netInv = false;
		}
	}
	
	public void look() {
		double yrotrad = GraphicsCore.rot.z/180*3.141592654;
		double z = GraphicsCore.rot.x/180*3.141592654;
		double x = Math.abs(Math.sin((GraphicsCore.rot.x)/180*3.141592654))*Math.sin(yrotrad);
		double y = Math.abs(Math.sin((GraphicsCore.rot.x)/180*3.141592654))*Math.cos(yrotrad);
		look = MathUtil.normalize(new Vertex(x,y,-Math.cos(z)));
		move = MathUtil.normalize(new Vertex(x,y,0));
	}
	
	public void move() {/*
		int i = 0;
		double t = MathUtil.magnitude(velocity);
		while((i == 0 || t > 0) && i < 10) {
			if(!jumping)
				onGround = onGround();
			else {
				jumping = false;
				onGround = false;
			}
			if(onGround) {
				setVelocity(MathUtil.multiply(velocity, new Vertex(0.6,0.6,0.6)));
				t = t * 0.6;
				Collision u = MathUtil.linePlaneIntersection(location, new Vertex(0,0,-foot*2), ground.t);
				Collision w = MathUtil.linePlaneIntersection(MathUtil.add(location, velocity), new Vertex(0,0,-foot*3), ground.t);
				if(u != null && w != null) {
					setVelocity(MathUtil.onVector(new Vertex(0, 0, 0), MathUtil.subtract(w.p, u.p), MathUtil.magnitude(velocity)));
				}
				Collision c = game.bsp.collideModel(location, velocity, model);
				if(c != null) {
					double d = dampen(velocity, c.t);
					setVelocity(MathUtil.onVector(new Vertex(0, 0, 0), MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
					setLocation(c.p);
					t -= c.d;
					//t = t * d;
				}
				else {
					move(velocity);
					t = 0;
				}
			}
			else {
				push(new Vertex(0,0,-0.3));
				setVelocity(MathUtil.multiply(velocity, new Vertex(0.95,0.95,0.95)));
				t = t * 0.95;
				Collision c = game.bsp.collideModel(location, velocity, model);
				if(c != null) {
					double d = dampen(velocity, c.t);
					setVelocity(MathUtil.onVector(new Vertex(0, 0, 0), MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
					setLocation(c.p);
					t -= c.d;
					//t = t * d;
				}
				else {
					move(velocity);
					t = 0;
				}
			}
			onGround = onGround();
			if(onGround) {
				velocity.z = 0;
				raise();
			}
			i++;
		}
		if(i >= 7)
			System.out.println("ALERT: " + i + " recursions were used in the last physics update. That is abnormally high.");
	*/}
	
	public void collision() {
		collision.move(location.copy());
	}
	
	public void inventory() {
		int i = 0;
		while(i < inventory.size()) {
			inventory.get(i).setLocation(location.copy());
			if(inventory.get(i).getType().contains("e")) {
				Equipment e = (Equipment) inventory.get(i);
				if(e.total <= 0) {
					drop(e.nid);
					e.kill();
				}
			}
			i++;
		}
	}
	
	public void equipment() {
		if(weapon != null) {
			weapon.setLocation(location.copy());
			weapon.setVelocity(velocity.copy());
		}
	}
	
	public void health() {
		if(health <= 0) {
			kill();
		}
		else {
			if(health < maxHealth)
				setHealth(health + 0.1);
			if(health > maxHealth)
				setHealth(maxHealth);
		}
	}
	
	public boolean take(Item i) {
		if(i.owner == null)
			if(!hasItem(i)) {
					i.owner = this;
					inventory.add(i);
					netInv = true;
					return true;
			}
		return false;
	}	
	
	public void drop(int i) {
		int j = 0;
		while(j < inventory.size()) {
			if(inventory.get(j).nid == i) {
				inventory.get(j).owner = null;
				inventory.remove(j);
			}
			j++;
		}
		equipment();
		netInv = true;
	}
	
	public void dropAll() {
		while(0 < inventory.size()) {
			inventory.get(0).owner = null;
			inventory.remove(0);
		}
		netInv = true;
	}
	
	public boolean hasItem(Item i) {
		if(i.dead)
			return true;
		if(i.getType().contains("e")) {
			if(((Equipment)i).stacks) {
					int j = 0;
					while(j < inventory.size()) {
						if(inventory.get(j).getType().contains("e")) {
							if(((Equipment)inventory.get(j)).equipmentType().equals(((Equipment)i).equipmentType())) {
								((Equipment)inventory.get(j)).setTotal(((Equipment)inventory.get(j)).total + ((Equipment)i).total);
								((Equipment)i).kill();
								return true;
							}
						}
						j++;
					}
			}
		}
		return false;
	}
	
	public void equipWeapon(Weapon w) {
		if(w != null) {
			game.engine.network.packetsOut.add(new Packet34Equip(w.nid, nid));
			weapon = w;
		}
		else {
			game.engine.network.packetsOut.add(new Packet34Equip(-1, nid));
			weapon = null;
		}
	}
	
	public void equipEquipment(Equipment e) {
		if(e != null) {
			game.engine.network.packetsOut.add(new Packet34Equip(e.nid, nid));
			equipment = e;
		}
		else {
			game.engine.network.packetsOut.add(new Packet34Equip(-2, nid));
			equipment = null;
		}
	}
	
	public String inventoryContents() {
		int i = 0;
		String s = "";
		while(i < inventory.size()) {
			if(inventory.get(i) != null)
				s += (i+1) + ": " + inventory.get(i).getName() + "\n";
			else
				s += (i+1) + ":\n";
			i++;
		}
		return s;
	}

	public void jump() {
		if(onGround) {
			push(new Vertex(0, 0, jumpHeight*2));
			jumping = true;
		}
	}
	
	public void setHealth(double h) {
		health = h;
		game.engine.network.packetsOut.add(new Packet42Health(nid, health));
	}
	
	public void damage(double d, Vertex i, Actor a) {
		setHealth(health-d);
		game.engine.network.packetsOut.add(new Packet13Push(nid, i.x, i.y, i.z));
		attacker = a;
	}
	
	public String toString() {
		return "Biped:" + name + ":" + nid;
	}
	
	public String getType() {
		return "b";
	}
	
	public void kill() {
		dropAll();
		//TODO: make actual method for messages (IE FOR REPRINTING IN CONSOLE)
		if(attacker != null)
			game.engine.network.sendMessage(name + " was fragged by " + attacker.name);
		else
			game.engine.network.sendMessage(name + " died.");
		dead = true;
	}
}
