package twelveengine;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import twelveengine.actors.Actor;
import twelveengine.actors.Equipment;
import twelveengine.actors.Hitscan;
import twelveengine.actors.Item;
import twelveengine.actors.Pawn;
import twelveengine.actors.Projectile;
import twelveengine.actors.Weapon;
import twelveengine.bsp.BSP;
import twelveengine.data.Respawner;
import twelveengine.data.Scenario;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet9Destroy;

public class Game {
	
	//Core Stuff
	public Engine engine;
	
	public Scenario scenario;
	
	public static int steptime = 30;
	public int time = 0;
	
	public BSP bsp;
	
	public ArrayList<Actor> actors = new ArrayList<Actor>();
	public ArrayList<Respawner> respawners = new ArrayList<Respawner>();
	
	public Game(Engine e, String s) {
		engine = e;
		loadLevel(s);
	}
	
	public void loadLevel(String s) {
		scenario = new Scenario(s);
		bsp = new BSP(this, scenario.bsp);
		
		int i = 0;
		String n = "";
		while(i < scenario.points.size()) {
			n = scenario.points.get(i).name;
			if(n.startsWith("respawner:")) {
				String file = n.split("=")[1];
				respawners.add(new Respawner(this,scenario.points.get(i),file));
			}
			i++;
		}
		
		System.out.println("Map: " + s + " loaded sucsessfully.");
	}
	
	public void step() {
		//Garbage time
		int i = 0;
		while(i < actors.size()) {
			if(actors.get(i).dead) {
				removeActor(actors.get(i).nid);
				i--;
			}
			i++;
		}
		//Game step
		i = 0;
		while(i < actors.size()) {
			actors.get(i).step();
			i++;
		}
		//Respawners check
		i = 0;
		while(i < respawners.size()) {
			respawners.get(i).step();
			i++;
		}
	}
	
	public void netStep() {
		//Send packets
		int i = 0;
		while(i < actors.size()) {
			Actor a = actors.get(i);
			a.netStep(engine.network.packetsOut);
			i++;
		}
	}
	
	public Actor spawnPlayer(int port, String name) {
		Actor a = addObject("object/character/generic", getSpawn(), new Vertex(0,0,0), new Vertex(0,0,0), port);
		Actor b = addObject("object/item/weapon/cr55rifle", new Vertex(0,0,0), new Vertex(0,0,0), new Vertex(0,0,0), -1);
		a.name = name;
		((twelveengine.actors.Biped)a).take((Item)b);
		return a;
	}
	
	public Vertex getSpawn() {
		int i = 0;
		ArrayList<Vertex> spawns = new ArrayList<Vertex>();
		while(i < scenario.points.size()) {
			if(scenario.points.get(i).name.equals("spawn=ffa")) {
				spawns.add(scenario.points.get(i));
			}
			i++;
		}
		return spawns.get((int)(Math.random()*spawns.size()));
	}
	
	public int gnid = 0;
	public int newNid() {
		gnid++;
		return gnid;
	}
	
	public Actor addObject(String f, Vertex l, Vertex v, Vertex r, int simulated) {
		ArrayList<String> file = new ArrayList<String>();
	    try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(f));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
	
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	file.add(currentLine);
			    currentLine=fileReader.readLine();
		    }
		    Actor a = createObject(file, newNid(), l, v, r);
		    a.file = f;
		    addActor(a, simulated);
		    return a;
	    }
	    catch(Exception e) {
	    	System.err.println("FAILED TO READ OBJECT: " + f);
	    	return null;
	    }
	}
	
	public Actor createObject(ArrayList<String> file, int n, Vertex l, Vertex v, Vertex r) throws Exception {
		String t = findProp(file, "class=");
		Actor a = null;
		if(t.equals("Pawn")) {
			Pawn p = new Pawn(this, n, findProp(file, "physmodel="));
			p.name = findProp(file, "name=");
			a = p;
		}
		if(t.equals("Item")) {
			Item i = new Item(this, n);
			i.name = findProp(file, "name=");
			a = i;
		}
		if(t.equals("Weapon")) {
			Weapon w = new Weapon(this, n, findProp(file, "primaryfire="), findProp(file, "secondaryfire="));
			w.name = findProp(file, "name=");
			w.simulatedProjectile = Boolean.parseBoolean(findProp(file, "simulatedProjectile="));
			w.rof = Integer.parseInt(findProp(file, "rateoffire="));
			w.impulse = Double.parseDouble(findProp(file, "impulse="));
			w.projectiles = Integer.parseInt(findProp(file, "projectiles="));
			w.spread = new Vertex(Double.parseDouble(findProp(file, "spreadx=")),Double.parseDouble(findProp(file, "spready=")),0);
			a = w;
		}
		if(t.equals("Equipment")) {
			Equipment e = new Equipment(this, n);
			e.name = findProp(file, "name=");
			e.type = findProp(file, "type=");
			e.stacks = Boolean.parseBoolean(findProp(file, "stacks="));
			e.total = Integer.parseInt(findProp(file, "total="));
			e.impulse = Double.parseDouble(findProp(file, "impulse="));
			e.fileCreateOnUse = findProp(file, "createOnuse=");
			a = e;
		}
		if(t.equals("Hitscan")) {
			Hitscan h = new Hitscan(this, n, Integer.parseInt(findProp(file, "lifespan=")));
			h.name = findProp(file, "name=");
			a = h;
		}
		if(t.equals("Projectile")) {
			Projectile p = new Projectile(this, n);
			p.name = findProp(file, "name=");
			p.life = Integer.parseInt(findProp(file, "lifespan="));
			p.damage = Double.parseDouble(findProp(file, "damage="));
			p.damageRadius = Double.parseDouble(findProp(file, "damageradius="));
			p.force = Double.parseDouble(findProp(file, "force="));
			a = p;
		}
		if(a == null)
			throw new Exception("ERROR PARSING OBJECT!");
		a.setLocation(l);
		a.setVelocity(v);
		a.setRotation(r);
		return a;
	}
	
	public String findProp(ArrayList<String> file, String s) {
		int i = 0;
		while(i < file.size()) {
			if(file.get(i).startsWith(s)) {
				return file.get(i).split(s)[1];
			}
			i++;
		}
		return "";
	}
	
	public Actor addActor(Actor a, int simulated) {
		actors.add(a);
		if(a.nid != -1) {
			Packet10Instantiate i = new Packet10Instantiate(a.nid, a.file, a.location.x, a.location.y, a.location.z, a.velocity.x, a.velocity.y, a.velocity.z, a.rotation.x, a.rotation.y, a.rotation.z);
			i.port = simulated;
			engine.network.packetsOut.add(i);
		}
		return a;
	}
	
	public Actor getActor(int n) {
		int i = 0;
		while(i < actors.size()) {
			if(actors.get(i).nid == n)
				return actors.get(i);
			i++;
		}
		return null;
	}
	
	public void removeActor(int n) {
		int i = 0;
		while(i < actors.size()) {
			if(actors.get(i).nid == n) {
				engine.network.packetsOut.add(new Packet9Destroy(actors.get(i).nid));
				actors.remove(i);
			}
			i++;
		}
	}
	
	public void pauseSounds() {
		
	}
	
	public void resumeSounds() {
		
	}
	
	public void adjustSoundVolume() {
		
	}
	
	public void unloadGame() {

	}

	public void checkSoundArray() {
		
	}
	
	public void log(String s) {
		System.out.println(s);
	}
	
}
