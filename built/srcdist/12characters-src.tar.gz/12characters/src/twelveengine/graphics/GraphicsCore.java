/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersengines.com/
 * 
 * GraphicsCore
 * Renders window and calls Core methods designated to perform specific graphics rendering.
 */

package twelveengine.graphics;
import twelveengine.Engine;
import twelveengine.data.Vertex;

public class GraphicsCore {
	
	/** Passed Engine Instance */
	@SuppressWarnings("unused")
	private Engine engine;
	
	public static Vertex tran = new Vertex(0,0,0);
	public static Vertex rot = new Vertex(0,0,0);
	/** Some necessary graphics files. */
	/** Display Settings */
	public int displayWidth;
	public int displayHeight;
	/** This is used to "zoom" on the player depending on screen resolution */

	int colorTextureID;
	int framebufferID;
	int depthRenderBufferID;
	
	/** Constructor for the GraphicsCore. Sets up the Display and initializes OpenGL.
	 * @param passedGame The Engine instance
	 */
	public GraphicsCore(Engine passedGame) {
		engine = passedGame;
	}
	
	/** Destroys the engine Display. */
	public void endGraphics() {
		
	}
	
	/** Draws all of the graphics as specified by the settings and current context. */
	public void renderGraphics() {		
		
	}
	
	public void cameraVector(float xx, float yy) {
		rot.x -= yy;
		rot.y = 0;
		rot.z -= xx;
		
		if(rot.x <= -180)
			rot.x = -180;
		if(rot.x >= 0)
			rot.x = 0;
		
		if(rot.z <= -360)
			rot.z += 360;
		if(rot.z >= 360)
			rot.z -= 360;
	}
	
	public int zoom = 1000;
	public void zoomHandle(int i) {
		zoom = zoom + i*50;
		if(zoom < 10)
			zoom = 10;
		if(zoom > 10000)
			zoom = 10000;
	}
	
	public void listenMouse() {
		
	}
	
	/** Sets the "zoom" on the player depending on screen resolution */
}