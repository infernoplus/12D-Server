package twelveengine.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet0Handshake;
import twelvelib.net.packets.Packet3Login;


public class Handshake extends Thread {
	public NetworkCore network;
	
	public int port;
	public ServerSocket providerSocket;
	public Socket connection;
	public ObjectOutputStream out;
	public ObjectInputStream in;
	
	public boolean disconnect = false;
	
	public Handshake(int a, NetworkCore b) {
		port = a;
		network = b;
		start();
	}

	  public void run() {
		  while(!disconnect) {
				try {
			  if(providerSocket != null)
					providerSocket.close();
			  if(connection != null)
				  connection.close();
			  if(out != null)
		    		out.close();
			  if(in != null)
		    		in.close();
				} catch (IOException e1) {
					System.err.println("Can't close previous handshake socket!");
				}
				  
			  
			  System.out.print("\nOpening handshake socket @" + port + "... ");
			  try {
				System.out.println(" Waiting for a connection");
				providerSocket = new ServerSocket(port);
	    		connection = providerSocket.accept();
	    		System.out.println("Connection received from " + connection.getInetAddress().getHostName());
	      
	    		out = new ObjectOutputStream(connection.getOutputStream());
	    		out.flush();
	    		in = new ObjectInputStream(connection.getInputStream());
	    		
				Packet l = (Packet) in.readObject();
				if(l.packetType() == 3) {
					//TODO: Authorize username
					Packet3Login j = (Packet3Login) l;
					if(network.players() > network.limit) {
						out.writeObject(new Packet0Handshake("", -1, network.name, network.motd, true, "Server is full"));
						out.flush();
					}
					else {
						System.out.println(j.username + " has logged in.");
						int p = network.addSocket(j.username);
	
						out.writeObject(new Packet0Handshake("", p, network.name, network.motd, false, ""));
						out.flush();
					}
				}
	    } 
	    catch (IOException e) {
	      System.err.println("Handshake failure!");
	    } catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	  }
	  }
	  
	  public void disconnect() {
		  disconnect = true;
		  try {
			  providerSocket.close();
			  connection.close();
			  out.close();
			  in.close();
		  } catch(Exception e) {
			  System.err.println("Failed to close handshake socket.");
		  }
	  }
}
