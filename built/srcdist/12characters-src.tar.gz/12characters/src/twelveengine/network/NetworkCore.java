package twelveengine.network;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

import twelveengine.Engine;
import twelveengine.actors.Actor;
import twelveengine.actors.Biped;
import twelveengine.actors.Equipment;
import twelveengine.actors.Item;
import twelveengine.actors.Weapon;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelvelib.net.packets.Packet17Equipment;
import twelvelib.net.packets.Packet32Pickup;
import twelvelib.net.packets.Packet33Drop;
import twelvelib.net.packets.Packet34Equip;
import twelvelib.net.packets.Packet40Damage;
import twelvelib.net.packets.Packet49Message;

public class NetworkCore {
	public Engine engine;
	
	public String name = "default";
	public String motd = "none";
	
	public int port = 2004;
	
	public int limit = 32;
	
	public boolean online = false;
	
	public long timeOut = 10000;
	
	public Handshake handshake;
	public ArrayList<ServerConnection> connections = new ArrayList<ServerConnection>();
	
	public ArrayList<Packet> packetsOut = new ArrayList<Packet>();
	public ArrayList<Packet> packetsIn = new ArrayList<Packet>();

	public NetworkCore(Engine a) {
		engine = a;
		openPort = port+2;
		System.out.println("Network ready!");
	}
	
	public void sendMessage(String s) {
		packetsOut.add(new Packet49Message(s));
	}
	
	public void step() {
		int i = 0;
		int j = 0;
		if(online) {
			//Timeouts
	    	engine.currentTime = engine.getTime();
			while(i < connections.size()) {
				if(!connections.get(i).loading)
					if (engine.currentTime - connections.get(i).hbLast > timeOut)
						connections.get(i).disconnect("Time out");
				i++;
			}
			//Incoming packets
			while(packetsIn.size() > 0) {
				parse(packetsIn.get(0));
				packetsIn.remove(0);
			}
			//Net step
			engine.game.netStep();
			//Outgoing packets
			while(packetsOut.size() > 0) {
				Packet p = packetsOut.get(0);
				while(j < connections.size()) {
					if(!connections.get(j).loading)
						connections.get(j).sendPacket(p);
					j++;
				}
				packetsOut.remove(0);
				j = 0;
			}
		}
	}
	
	public void parse(Packet p) {
		try {
			if(p.packetType() == 10)
				packet10(p);
			if(p.packetType() == 11)
				packet11(p);
			if(p.packetType() == 12)
				packet12(p);
			if(p.packetType() == 17)
				packet17(p);
			if(p.packetType() == 32)
				packet32(p);
			if(p.packetType() == 33)
				packet33(p);
			if(p.packetType() == 34)
				packet34(p);
			if(p.packetType() == 40)
				packet40(p);
		}
		catch(Exception e) {
			System.err.println("Failed to parse packet!");
			e.printStackTrace();
		}
	}
	
	public void packet10(Packet p) {
		Packet10Instantiate i = (Packet10Instantiate) p;
		engine.game.addObject(i.type, new Vertex(i.x,i.y,i.z), new Vertex(i.i, i.j, i.k), new Vertex(i.m,i.n,i.o), i.port);
	}
	
	public void packet11(Packet p) {
		Packet11Location l = (Packet11Location) p;
		Actor a = engine.game.getActor(l.nid);
		if(a != null) {
			a.setLocation(new Vertex(l.x, l.y, l.z));
			a.setVelocity(new Vertex(l.i, l.j, l.k));
		}
	}
	
	public void packet12(Packet p) {
		Packet12Rotation r = (Packet12Rotation) p;
		Actor a = engine.game.getActor(r.nid);
		if(a != null)
			a.setRotation(new Vertex(r.x, r.y, r.z));
	}
	
	public void packet17(Packet p) {
		Packet17Equipment e = (Packet17Equipment) p;
		Actor a = engine.game.getActor(e.equip);
		if(a != null)
			if(a.getType().contains("e")) {
				((Equipment)a).setTotal(e.total);
			}
	}
	
	public void packet32(Packet p) {
		Packet32Pickup i = (Packet32Pickup) p;
		Actor a = engine.game.getActor(i.owner);
		Actor b = engine.game.getActor(i.item);
		if(a != null && b != null)
			if(b.getType().contains("i") && a.getType().contains("b"))
				((Biped)a).take((Item)b);
	}
	
	public void packet33(Packet p) {
		Packet33Drop d = (Packet33Drop) p;
		Actor a = engine.game.getActor(d.owner);
		if(a != null )
			((Biped)a).drop(d.slot);
	}
	
	public void packet34(Packet p) {
		Packet34Equip e = (Packet34Equip) p;
		if(e.item == -1) {
			Actor b = engine.game.getActor(e.player);
			((Biped)b).equipWeapon(null);
		}
		else if(e.item == -2) {
			Actor b = engine.game.getActor(e.player);
			((Biped)b).equipEquipment(null);
		}
		else {
			Actor a = engine.game.getActor(e.item);
			Actor b = engine.game.getActor(e.player);
			if(a.getType().contains("w"))
				((Biped)b).equipWeapon((Weapon)a);
			if(a.getType().contains("e"))
				((Biped)b).equipEquipment((Equipment)a);
		}
	}
	
	public void packet40(Packet p) {
		Packet40Damage d = (Packet40Damage) p;
		Actor a = engine.game.getActor(d.owner);
		Actor b = engine.game.getActor(d.hit);
		if(a != null && b != null) {
			b.damage(d.damage, new Vertex(0,0,0), a);
			packetsOut.add(p);
		}
	}
	
	public void serverSetup() {
		System.out.println("- Server Information -");
		System.out.println("++ Name: " + name);
		System.out.println("++ MOTD: " + motd);
		System.out.println("++ Port: " + port);
		System.out.println("++ Players: " + limit);
		System.out.println("- Starting Server -");
		if(!checkPort(port)) {
			System.err.println("## Handshake port is not open! Netstart fail.");
			return;
		}
		try {
			handshake = new Handshake(port, this);
		}
		catch(Exception e) {
			System.err.println("## Netstart fail.");
			e.printStackTrace();
		}
		finally {
			online = true;
			System.out.println("- Server Running -");
		}
		
	}
	
	public void close() {
		int i = 0;
		handshake.disconnect();
		while(i < connections.size()) {
			connections.get(i).disconnect("Server net stop");
			i++;
		}
		online = false;
		System.out.println("- Server Stopped -");
	}
	
	public int addSocket(String n) {
		int i = openPort();
		System.out.println("Open port @" + i);
		connections.add(new ServerConnection(i, this, n));
		return i;
	}
	
	public void playerDisconnect(int p) {
		int i = 0;
		while(i < connections.size()) {
			if(connections.get(i).port == p)
				connections.remove(i);
			i++;
		}
	}
	
	public int players() {
		return connections.size();
	}
	
	public int openPort;
	public int openPort() {
		openPort++;
		while(!checkPort(openPort)) {
			openPort++;
		}
		return openPort;
	}
	
	public boolean checkPort(int p) {
		boolean portTaken = false;
		ServerSocket socket = null;
		try {
			socket = new ServerSocket(p);
		} catch (IOException e) {
			portTaken = true;
		} finally { 
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				} 
			}
		}
		return !portTaken;
	}
}
