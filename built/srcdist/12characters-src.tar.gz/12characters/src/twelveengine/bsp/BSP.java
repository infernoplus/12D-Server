package twelveengine.bsp;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysModel;
import twelveengine.data.Vertex;
import twelveengine.graphics.Model;
import twelveutil.MathUtil;

public class BSP {	
	public Game game;
	public String name;
	
	public Model meshes[];
	public PhysModel phys[];
	
	public double size = 128;
	public Chunk[][][] chunks;
	
	public Vertex boundNeg;
	public Vertex boundPos;
	
	public BSP (Game w, String b) {
		game = w;
		readBSP(b);
		genChunks();
	}
	
	int mnum = 0;
	public void readBSP(String s) {
		try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(s));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
		    
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	if(currentLine.startsWith("mesh<"))
		    		mnum++;
			    currentLine=fileReader.readLine();
		    }
		    fileReader.close();
		} catch (IOException e) {
			System.err.println("FAILED TO READ SCENARIO: " + s);
		}
		
		System.out.print("\nBSP consists of " + mnum + " meshes... Building: ");
		meshes = new Model[mnum];
		phys = new PhysModel[mnum];
		mnum = 0;
		
		try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(s));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
		    
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	if(currentLine.startsWith("bsp="))
		    		name = currentLine.split("=")[1];
		    	if(currentLine.startsWith("mesh<")) {
		    		String t = currentLine.split("=")[1];
		    		String u = currentLine.split("=")[0].split("<")[1].split(">")[0];
		    		readStatic(u, new Vertex(Double.parseDouble(t.split(",")[0]), Double.parseDouble(t.split(",")[1]), Double.parseDouble(t.split(",")[2])), Double.parseDouble(t.split(",")[3]));
		    	}
			    currentLine=fileReader.readLine();
		    }
		    fileReader.close();
			System.out.println("done!");
		} catch (IOException e) {
			System.err.println("FAILED TO READ SCENARIO: " + s);
		}
		
	}
	
	public void readStatic(String s, Vertex v, double d) {
	    String mesh = "";
	    String phy = "";
		try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(s));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
		    
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	if(currentLine.startsWith("visualMesh="))
		    		mesh = currentLine.split("=")[1];
		    	if(currentLine.startsWith("collisionMesh="))
		    		phy = currentLine.split("=")[1];
			    currentLine=fileReader.readLine();
		    }
		    fileReader.close();
		    meshes[mnum] = new Model(v, d, mesh);
			phys[mnum] = new PhysModel(v, d, phy);
			System.out.print(s + ", ");
			mnum++;
		} catch (Exception e) {
			System.err.println("FAILED TO READ STATIC: " + s);
		}
	}
	
	int x;
	int y;
	int z;
	
	public void genChunks() {
		boundNeg = new Vertex(0, 0, 0);
		boundPos = new Vertex(0, 0, 0);
		int i = 0;
		int j = 0;
		while(j < phys.length) {
			while(i < phys[j].v.length) {
				if(phys[j].v[i].x < boundNeg.x)
					boundNeg.x = phys[j].v[i].x;
				if(phys[j].v[i].x > boundPos.x)
					boundPos.x = phys[j].v[i].x;
				if(phys[j].v[i].y < boundNeg.y)
					boundNeg.y = phys[j].v[i].y;
				if(phys[j].v[i].y > boundPos.y)
					boundPos.y = phys[j].v[i].y;
				if(phys[j].v[i].z < boundNeg.z)
					boundNeg.z = phys[j].v[i].z;
				if(phys[j].v[i].z > boundPos.z)
					boundPos.z = phys[j].v[i].z;
				i++;
			}
			i = 0;
			j++;
		}
		Vertex boundTot = MathUtil.subtract(boundNeg, boundPos);
		game.log("Total world size: " + MathUtil.toString(boundTot));
		x = (int) Math.ceil(Math.abs(boundTot.x/size));
		y = (int) Math.ceil(Math.abs(boundTot.y/size));
		z = (int) Math.ceil(Math.abs(boundTot.z/size));
		game.log("Chunks to generate: " + x + " " + y + " " + z + " = " + x*y*z + " ...");
		
		chunks = new Chunk[x][y][z];
		i = 0;
		j = 0;
		int k = 0;
		
		while(k < z) {
			while(j < y) {
				while(i < x) {
					chunks[i][j][k] = new Chunk(this, i, j, k);
					i++;
				}
				i = 0;
				j++;
			}
			j = 0;
			k++;
		}
		game.log("Done!");
		game.log("");
	}
	
	public Collision collidePoint(Vertex a, Vertex b) {
		int i = 0;
		int j = 0;
		Chunk u[] = getChunks(a);
		Collision c = null;
		while(j < u.length) {
			if(u[j] != null)
			while(i < u[j].f.size()) {
				//is the triangle in bounds to test?
				//if(MathUtil.magnitude(b) + 20 +  worldCollision.f[i].radius > MathUtil.length(a,  worldCollision.f[i].center)) {
					Collision d = MathUtil.lineTriangleIntersection(a, b, u[j].f.get(i));
					if(d != null) {
						if(c != null) {
							if(d.d <= c.d)
								c = d;
						}
						else
							c = d;
					}
				//}
				i++;
			}
			j++;
			i=0;
		}
		return c;
	}
	
	public Collision collideSphereIncremental(Vertex a, Vertex b, double r) {
		double c = r/2;
		double d = MathUtil.magnitude(b);
		double e = c;
		while(e < d) {
			Collision o = collideSphere(MathUtil.onVector(a, b, e), r);
			if(o != null) {
				o.d = r-o.d;
				o.p = a;
				Vertex iv = MathUtil.inverse(MathUtil.normalize(b));
				double dp = MathUtil.dotProduct(o.t.normal, iv);
				Vertex f = MathUtil.multiply(MathUtil.subtract(MathUtil.multiply(o.t.normal, new Vertex(2*dp,2*dp,2*dp)), iv), 1);
				o.r = f;
				return o;
			}
			e += c;
		}
		Collision o = collideSphere(MathUtil.add(a, b), r);
		if(o != null) {
			o.d = r-o.d;
			o.p = a;
			Vertex iv = MathUtil.inverse(MathUtil.normalize(b));
			double dp = MathUtil.dotProduct(o.t.normal, iv);
			Vertex f = MathUtil.multiply(MathUtil.subtract(MathUtil.multiply(o.t.normal, new Vertex(2*dp,2*dp,2*dp)), iv), 1);
			o.r = f;
			return o;
		}
		return null;
	}
	
	public Collision collideSphere(Vertex a, double r) {
		int i = 0;
		int j = 0;
		Chunk u[] = getChunks(a);
		Collision c = null;
		while(j < u.length) {
			if(u[j] != null)
				while(i < u[j].f.size()) {
					Collision d = MathUtil.sphereTriangleIntersection(a, r, u[j].f.get(i));
					if(d != null) {
						if(c != null) {
							if(d.d <= c.d)
								c = d;
						}
						else
							c = d;
					}
					i++;
				}
			j++;
			i=0;
		}
		return c;
	}
	
	public Collision collideModel(Vertex a, Vertex b, Model m) {
		int i = 0;
		int j = 0;
		int k = 0;
		Chunk u[] = getChunks(a);
		Collision c = null;
		while(j < m.v.length) {
			Vertex e = MathUtil.add(a, m.v[j]);
			while(k  < u.length) {
				if(u[k] != null)
					while(i < u[k].f.size()) {
						//is the triangle in bounds to test?
						if(MathUtil.magnitude(b) + m.radius + u[k].f.get(i).radius > MathUtil.length(a, u[k].f.get(i).center)) {
							Collision d = MathUtil.lineTriangleIntersection(e, b, u[k].f.get(i));
							if(d != null) {
								if(c != null) {
									if(d.d <= c.d) {
										d.p = MathUtil.subtract(d.p, m.v[j]);
										c = d;
									}
								}
								else {
									d.p = MathUtil.subtract(d.p, m.v[j]);
									c = d;
								}
							}
						}
						i++;
					}
				k++;
				i=0;
			}
			k=0;
			j++;
		}/*
			i=0;
			j=0;
			while(j < worldCollision.e.length) {
				while(i < m.f.length) {
					//is the triangle in bounds to test?
					//if(MathUtil.magnitude(b) + 20 +  worldCollision.f[i].radius > MathUtil.length(a,  worldCollision.f[i].center)) {
						Vertex r = MathUtil.subtract(worldCollision.e[j].b, worldCollision.e[j].a);
						Triangle t = m.f[i].move(a);
						t.collisionData();
						Collision d = MathUtil.lineTriangleIntersection(worldCollision.e[j].a, r, t);
						if(d != null) {
							System.out.println("intersection");
							Vertex iv = MathUtil.inverse(MathUtil.normalize(b));
							double dp = MathUtil.dotProduct(d.t.normal, iv);
							Vertex ar = MathUtil.onVector(new Vertex(0,0,0), MathUtil.subtract(MathUtil.multiply(d.t.normal, new Vertex(2*dp,2*dp,2*dp)), iv), MathUtil.magnitude(b));
							return new Collision(a, ar, d.t, 0);
						}
					//}
					i++;
				}
				i=0;
				j++;
			}*/
		return c;
	}
	
	public Collision onGroundSphere(Vertex l, double r, double h) {
		int i = 0;
		int j = 0;
		Chunk u[] = getChunks(l);
		Vertex a = new Vertex(l.x, l.y, l.z-h);
		Collision c = null;
		while(j < u.length) {
			if(u[j] != null)
				while(i < u[j].f.size()) {
					Collision d = MathUtil.sphereTriangleIntersection(a, r, u[j].f.get(i));
					if(d != null) {
						if(MathUtil.normalSteep(new Vertex(0, 0, 1), d.t) <= 0.40) {
							if(c != null) {
								if(d.d <= c.d)
									c = d;
							}
							else
								c = d;
						}
					}
					i++;
				}
			j++;
			i=0;
		}
		return c;
	}
	
	public Chunk[] getChunks(Vertex v) { 
		int i = (int)Math.floor(Math.abs((boundNeg.x - v.x)/size));
		int j = (int)Math.floor(Math.abs((boundNeg.y - v.y)/size));
		int k = (int)Math.floor(Math.abs((boundNeg.z - v.z)/size));
		
		Chunk z = getChunk(i, j, k);
		
		return new Chunk[] {z};

	}
	
	public Chunk getChunk(int i, int j, int k) {
		if(i >= 0 && i < x && j >= 0 && j < y && k >= 0 && k < z)
			return chunks[i][j][k];
		else
			return null;
	}

	
	public String toString() {
		return "BSP:" + name;
	}

}
