package twelveengine.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import twelveengine.Engine;
import twelveengine.actors.Actor;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelveutil.MathUtil;

public class CommandLine extends Thread {
	public Engine engine;
	public boolean run = true;
	public CommandLine(Engine g) {
		engine = g;
		start();
		System.out.println("Command Line ready!");
	}
	
	public void run() {
		InputStreamReader converter = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(converter);
		String i = "";
		while(!engine.stopRuntime && run) {
				try {
					i = in.readLine();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
				if(i.startsWith("/exit"))
					run = false;
				s = i;
				n = true;
		}
	}
	
	public boolean n = false;
	public String s = "";
	
	public void step() {
		boolean b = false;
		if(n) {
			try {
				if(s.startsWith("/load ")) {
					String f[] = s.split("/load ");
					engine.loadGame(f[1]);
					b = true;
				}
				if(s.startsWith("/netstart")) {
					if(engine.game != null && !engine.network.online)
						engine.network.serverSetup();
					else
						System.out.println("## World not loaded or already online!");
					b = true;
				}
				if(s.startsWith("/netstop")) {
					if(engine.network.online)
						engine.network.close();
					else
						System.out.println("## Not online.");
					b = true;
				}
				if(s.startsWith("/netname ")) {
					String f[] = s.split("/netname ");
					engine.network.name = f[1];
					b = true;
				}
				if(s.startsWith("/netmotd ")) {
					String f[] = s.split("/netmotd ");
					engine.network.motd = f[1];
					b = true;
				}
				if(s.startsWith("/netport ")) {
					String f[] = s.split("/netport ");
					engine.network.port = Integer.parseInt(f[1]);
					b = true;
				}
				if(s.startsWith("/netlimit ")) {
					String f[] = s.split("/netlimit ");
					engine.network.limit = Integer.parseInt(f[1]);
					b = true;
				}
				if(s.startsWith("/say ")) {
					String f = s.split("/say ")[1];
					engine.network.sendMessage("[SERVER] " + f);
					b = true;
				}
				if(s.startsWith("/players")) {
					int i = 0;
					System.out.println("Players Online:");
					while(i < engine.network.connections.size()) {
						System.out.println(" -- " + engine.network.connections.get(i).name + " @ " + engine.network.connections.get(i).connection.getInetAddress().getHostName() + ":" + engine.network.connections.get(i).port + " controlling:" + engine.network.connections.get(i).control);
						i++;
					}
					b = true;
				}
				if(s.startsWith("/objects")) {
					int i = 0;
					System.out.println("Objects in world:");
					while(i < engine.game.actors.size()) {
						System.out.println(" -- " + engine.game.actors.get(i).toString() + " : " + MathUtil.toString(engine.game.actors.get(i).location));
						i++;
					}
					b = true;
				}
				if(s.startsWith("/spawn ")) {
					if(engine.game != null) {
						String f = s.split("/spawn ")[1];
						Actor a = engine.game.addObject(f, new Vertex(0,0,0), new Vertex(0,0,0), new Vertex(0,0,0), -1);
						System.out.println("Spawned: " + a.toString() + " @ {0,0,0}");
					}
					b = true;
				}
				if(s.startsWith("/destroy ")) {
					String f = s.split("/destroy ")[1];
					Actor a = engine.game.getActor(Integer.parseInt(f));
					if(a != null)
						a.kill();
					b = true;
				}
				if(s.startsWith("/tp ")) {
					String f[] = s.split("/tp ");
					f = f[1].split(" ");
					engine.network.name = f[1];
					int nid = Integer.parseInt(f[0]);
					double x = Double.parseDouble(f[1]);
					double y = Double.parseDouble(f[2]);
					double z = Double.parseDouble(f[3]);
					if(engine.network.online) { 
						Actor a = engine.game.getActor(nid);
						if(a != null) {
							a.setLocation(new Vertex(x, y, z));
							engine.network.packetsOut.add(new Packet11Location(a.nid, true, x, y, z, a.velocity.x, a.velocity.y, a.velocity.z));
							engine.network.packetsOut.add(new Packet12Rotation(a.nid, true, a.rotation.x, a.rotation.y, a.rotation.z));
						}
					}
					b = true;
				}
				if(s.startsWith("/fusrodah ")) {
					String f[] = s.split("/fusrodah ");
					f = f[1].split(" ");
					engine.network.name = f[1];
					int nid = Integer.parseInt(f[0]);
					double x = Double.parseDouble(f[1]);
					double y = Double.parseDouble(f[2]);
					double z = Double.parseDouble(f[3]);
					if(engine.network.online) { 
						Actor a = engine.game.getActor(nid);
						if(a != null) {
							a.push(new Vertex(x, y, z));
							engine.network.packetsOut.add(new Packet11Location(a.nid, true, a.location.x, a.location.y, a.location.z, x, y, z));
							engine.network.packetsOut.add(new Packet12Rotation(a.nid, true, a.rotation.x, a.rotation.y, a.rotation.z));
						}
					}
					b = true;
				}
				if(s.startsWith("/exit")) {
					engine.stopRuntime = true;
					b = true;
				}
				if(s.startsWith("/help")) {
					System.out.println("I am sorry but this is of no help.");
					b = true;
				}
				if(!b)
					System.out.println("## No such command. Try /help");
			}
			catch(Exception e) {
				System.err.println("## Command failed.");
				e.printStackTrace();
			}
			s = "";
			n = false;
		}

	}
}
