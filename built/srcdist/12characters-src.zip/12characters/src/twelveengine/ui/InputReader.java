/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersengines.com/
 * 
 * InputReader
 * Reads input and affects the engine state accordingly.
 */

package twelveengine.ui;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import de.matthiasmann.twl.Event;

import twelveengine.Engine;

public class InputReader {
	
	public static boolean lmb = false;
	public static boolean rmb = false;
	public static boolean mmb = false;
	
	public static ArrayList<Integer> keys = new ArrayList<Integer>();
	
	public static boolean readInput(Engine engine, Event evt) {
		return evt.isMouseEventNoWheel();
	}
}