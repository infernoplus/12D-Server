package twelveengine.actors;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Vertex;

public class Weapon extends Item {
	
	public boolean simulatedProjectile;
	
	public boolean primary = false;
	public boolean secondary = false;
	
	public String primaryFile;
	public String secondaryFile;
	public ArrayList<String> primaryCache;
	public ArrayList<String> secondaryCache;
	
	public int rof;
	
	public double impulse;
	public int projectiles;
	
	public Vertex spread;
	
	public int shotCount = 0;
	public int shotTimer = 0;
	
	public Weapon(Game w, int n, String p, String s) {
		super(w, n);
		simulatedProjectile = false;
		rof = 30;
		impulse = 30;
		projectiles=1;
		spread = new Vertex(0,0,0);
		primaryFile = p;
		secondaryFile = s;
		if(!p.equals(""))
			primaryCache = cacheObject(p);
		if(!s.equals(""))
			secondaryCache = cacheObject(p);
	}
	
	public ArrayList<String> cacheObject(String o) {
		ArrayList<String> file = new ArrayList<String>();
	    try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(o));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
	
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	file.add(currentLine);
			    currentLine=fileReader.readLine();
		    }
		    return file;
	    }
	    catch(Exception e) {
		    return null;
	    }
	}
	
	public void step() {
		if(owner == null) {
			move();
			idle++;
			if(idle >= maxIdle) {
				kill();
			}
		}
		else {
			idle=0;
		}
	}
	
	public void cooldown() {
		if(shotTimer > 0)
			shotTimer--;
	}
	
	public String getType() {
		return "iw";
	}
	
	public String toString() {
		return "Weapon:" + name + ":" + nid;
	}
}