package twelveengine.actors;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelveutil.MathUtil;

public class Item extends Actor {
	public Actor owner;
	
	public String name;
	
	public double drag;
	public double friction;
	
	public int idle = 0;
	public int maxIdle = 2400;
	
	public Item(Game w, int n) {
		super(w, n);
		owner = null;
		drag = 0.96;
		friction = 0.8;
	}
	
	public void step() {
		if(owner == null) {
			move();
			idle++;
			if(idle >= maxIdle) {
				kill();
			}
		}
		else {
			idle=0;
		}
	}
	
	public void netStep(ArrayList<Packet> out) {
		if(owner == null) {
			if(netLoc) {
				out.add(new Packet11Location(nid, false, location.x, location.y, location.z, velocity.x, velocity.y, velocity.z));
				netLoc = false;
			}
			if(netRot) {
				out.add(new Packet12Rotation(nid, false, rotation.x, rotation.y, rotation.z));
				netRot = false;
			}
		}
	}
	
	public void move() {
		if(pointOnGround() && MathUtil.magnitude(velocity) < 1) {
			setVelocity(new Vertex(0,0,0));
		}
		else {
			push(new Vertex(0,0,-0.3));
			setVelocity(MathUtil.multiply(velocity, drag));
			int i = 0;
			double t = MathUtil.magnitude(velocity);
			while((i == 0 || t > 0) && i < 10) {
				Vertex recvel = MathUtil.multiply(MathUtil.normalize(velocity), t);
				Collision c = game.bsp.collidePoint(location, recvel);
				if(c != null) {
					double d = dampen(velocity, c.t);
					setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
					setVelocity(MathUtil.multiply(velocity, friction));
					setLocation(c.p);
					t -= c.d;
					t = t*friction;
				}
				else {
					move(recvel);
					t = 0;
				}
				i++;
			}
		}
	}
	
	public boolean pointOnGround() {
		Collision c = game.bsp.collidePoint(location, new Vertex(0,0,-0.25));
		if(c != null) {
			if(MathUtil.normalSteep(new Vertex(0, 0, 1), c.t) <= 0.40) {
				return true;
			}
		}
		return false;
	}
	
	//old physics
	/*public void move() {
		push(new Vertex(0,0,-0.3));
		setVelocity(MathUtil.multiply(velocity, drag));
		int i = 0;
		double t = MathUtil.magnitude(velocity);
		while((i == 0 || t > 0) && i < 10) {
			Vertex recvel = MathUtil.multiply(MathUtil.normalize(velocity), t);
			Collision c = game.bsp.collidePoint(location, recvel);
			if(c != null) {
				double d = dampen(velocity, c.t);
				setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
				setLocation(c.p);
				t -= c.d;
			}
			else {
				move(recvel);
				t = 0;
			}
			i++;
		}
	}*/
	
	
	public double dampen(Vertex v, PhysTriangle t) {
		double d = MathUtil.normalSteep(MathUtil.normalize(MathUtil.inverse(v)), t);
		return d;
	}
	
	public void damage(double d, Vertex i, Actor a) {
		push(i);
	}
	
	public String toString() {
		return "Item:" + name + ":" + nid;
	}
	
	public String getType() {
		return "i";
	}
}
