package twelveengine.actors;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelveengine.graphics.Model;
import twelveutil.MathUtil;

public class Projectile extends Actor {
	public String file;
	
	public Actor owner;
	
	public Model model;
	
	public boolean expended = false;
	
	public int life;
	public double drag;
	public double friction;
	
	public double damage;
	public double damageRadius;
	public double force;
	
	public Projectile(Game w, int n) {
		super(w, n);
		owner = null;
		life = 90;
		drag = 0.96;
		friction = 0.8;
		damage = 50;
		damageRadius = 3;
		force = 3;
	}
	
	public void step() {
		if(!expended) {
			move();
			projectile();
		}
	}
	
	public void move() {
		if(pointOnGround() && MathUtil.magnitude(velocity)  < 1) {
			setVelocity(new Vertex(0,0,0));
		}
		else {
			push(new Vertex(0,0,-0.2));
			setVelocity(MathUtil.multiply(velocity, drag));
			int i = 0;
			double t = MathUtil.magnitude(velocity);
			while((i == 0 || t > 0) && i < 10) {
				Vertex recvel = MathUtil.multiply(MathUtil.normalize(velocity), t);
				Collision c = game.bsp.collidePoint(location, recvel);
				if(c != null) {
					double d = dampen(velocity, c.t);
					setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
					setVelocity(MathUtil.multiply(velocity, friction));
					setLocation(c.p);
					t -= c.d;
					t = t*friction;
				}
				else {
					move(recvel);
					t = 0;
				}
				i++;
			}
		}
	}
	
	public boolean pointOnGround() {
		Collision c = game.bsp.collidePoint(location, new Vertex(0,0,-0.1));
		if(c != null) {
			if(MathUtil.normalSteep(new Vertex(0, 0, 1), c.t) <= 0.40) {
				return true;
			}
		}
		return false;
	}
	
	public void projectile() {
		if(life > 0) {
			life--;
		}
		else {
			detonate();
		}
	}
	
	public void detonate() {
		int i = 0;
		while(i < game.actors.size()) {
			if(MathUtil.length(location, game.actors.get(i).location) < damageRadius) {
				Vertex v = new Vertex(0,0,0);
				if(force != 0) {
					v = MathUtil.multiply(MathUtil.normalize(MathUtil.subtract(game.actors.get(i).location, location)), force);
				}
				game.actors.get(i).damage(damage, v, this);
			}
			i++;
		}
		
		expended = true;
		kill();
	}
	
	
	public double dampen(Vertex v, PhysTriangle t) {
		double d = MathUtil.normalSteep(MathUtil.normalize(MathUtil.inverse(v)), t);
		return d;
	}
	
	public void damage(double d, Vertex i, Actor a) {
		push(i);
	}
	
	public String toString() {
		return "Projectile:" + name + ":" + nid;
	}
	
	public String getType() {
		return "g";
	}
}
