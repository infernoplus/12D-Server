package twelveengine.graphics;

public class Material {
	public double color[];
	public String material;
	public Texture texture;
	
	public Material(String s) {
		material = s;
	}
	public void glMaterialSet() {
		
	}
}
