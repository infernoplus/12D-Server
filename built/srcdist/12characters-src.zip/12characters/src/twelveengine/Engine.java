/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Engine
 * Runs the engine. Stores/calls the graphics, audio, input cores. Also stores frames-per-second.
 */
			
package twelveengine;

import org.lwjgl.Sys;

import twelveengine.Game;
import twelveengine.network.NetworkCore;
import twelveengine.ui.CommandLine;
import twelvelib.net.packets.Packet4Load;

public class Engine {
	
	/** That's the name of the game, baby! */
	public final String gameTitle = "12D Server Alpha";
	public final String version = "v0.0.3 Dev";
	/** Core Instances */
	public Console console;
	public NetworkCore network;
	public Game game;
	public CommandLine command;
	/** Menu variables */
	public boolean menuIsOpen = false;
	/** Kills the program upon enable */
	public boolean stopRuntime = false;
	/** BSP Step Variables */
	public long currentTime;
	private long lastFrame = getTime();
	
	public Thread renderer = null;

	/** Engine starts here! */
	public void start() {
		System.out.println("Loading engine...");
		console = new Console(this);
		network = new NetworkCore(this);
		command = new CommandLine(this);
		System.out.println("\nEngine ready!");
	}
	
	public void loadGame(String s) {
		if(network.online) {
			network.packetsOut.add(new Packet4Load(s));
			network.step();
		}
		if(game != null)
			game.unloadGame();
		game = new Game(this, s);
		if(network.online)
			network.sendMessage("Loading map:" + game.scenario.name);
	}

	/** Engine runs here! */
	public void run() {
		while(game == null && !stopRuntime) {
			command.step();
		}
		while (!stopRuntime) {
			command.step();
			currentTime = getTime();
			if (currentTime - lastFrame > Game.steptime) {
			    game.step();
				network.step();
		       	lastFrame = currentTime;
			}
		}
    }

	/** Engine ends here! */
	public void end() {
		System.out.println("\nStopping engine...");
		network.close();
		if(game != null)
			game.unloadGame();
		System.out.println("Game stopped!");
	}
	
	/** Pauses/Unpauses the game and enables/disables the menu. */
	public void toggleMenu() {
		
	}

	/** Get method for the current time.
	 * @return The time in milliseconds, stored as a long.
	 */
    public long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }
}
