package twelveengine.bsp;

import java.util.ArrayList;

import twelveengine.bsp.BSP;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelveutil.MathUtil;

public class Chunk {
	public BSP bsp;
	
	Vertex start;
	double size;
	
	int x;
	int y;
	int z;
	
	Vertex cN;
	Vertex cP;
	Vertex center;
	
	double radius;
	
	public ArrayList<PhysTriangle> f = new ArrayList<PhysTriangle>();
	
	public float color[] = new float[] {(float)Math.random(),(float)Math.random(),(float)Math.random()};
	
	public Chunk(BSP w, int a, int b, int c) {
		bsp = w;
		start = bsp.boundNeg;
		size = bsp.size;
		x = a;
		y = b;
		z = c;
		cN = new Vertex(start.x + (x*size), start.y + (y*size), start.z + (z*size));
		cP = new Vertex(start.x + ((x+1)*size), start.y + ((y+1)*size), start.z + ((z+1)*size));
		center = MathUtil.add(cN, new Vertex(size/2, size/2, size/2));
		radius = MathUtil.length(cN, cP)/2;
		gen();
	}
	
	public void gen() {
		int i = 0;
		int j = 0;
		while(j < bsp.phys.length) {
			while(i < bsp.phys[j].f.length) {
				if(MathUtil.length(center, bsp.phys[j].f[i].center) - (bsp.phys[j].f[i].radius + size*1.41421356237) <= 0)
					f.add(bsp.phys[j].f[i]);
				i++;
			}
		j++;
		i=0;
		}
	}
	
	public boolean contains(Vertex a) {
		if(a.x >= cN.x && a.x <= cP.x && a.y >= cN.y && a.y <= cP.y && a.z >= cN.z && a.z <= cP.z) {
			return true;
		}
		return false;
	}		
}
