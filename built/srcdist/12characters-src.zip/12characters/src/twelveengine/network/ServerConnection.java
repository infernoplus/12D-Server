package twelveengine.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import twelveengine.actors.Actor;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet1Join;
import twelvelib.net.packets.Packet20Control;
import twelvelib.net.packets.Packet2Disconnect;
import twelvelib.net.packets.Packet49Message;
import twelvelib.net.packets.Packet4Load;
import twelvelib.net.packets.Packet53Team;


public class ServerConnection extends Thread {
	public NetworkCore network;
	
	public String name;
	public int port;
	
	public ServerSocket providerSocket;
	public Socket connection;
	public ObjectOutputStream out;
	public ObjectInputStream in;

	public boolean disconnect = false;
	
	public boolean loading = true;
	public long hbLast;
	
	public int control;
	public int team;
	
	public ServerConnection(int a, NetworkCore b, String n) {
		port = a;
		network = b;
		name = n;
		control = -1;
		start();
	}

	public void run() {
	  System.out.print("\nOpening socket @" + port + " for " + name + "... ");
	  try {
		providerSocket = new ServerSocket(port);
		connection = providerSocket.accept();
		System.out.println("Connection received from " + name + "@" + connection.getInetAddress().getHostName() + ":" + port);
  
		out = new ObjectOutputStream(connection.getOutputStream());
		out.flush();
		in = new ObjectInputStream(connection.getInputStream());
		
		out.writeObject(new Packet4Load(network.engine.game.scenario.file));
		
		Packet p = (Packet) in.readObject();
		if(p.packetType() == 1) {	
			Packet1Join j = (Packet1Join) p;
			if(!j.join)
				throw new Exception("Player returned no load! Disconnect.");
			System.out.println(name + " has joined the game!");
		}
	  	else
			throw new Exception("Bad packet from player! Disconnect.");
		
		//network.packets.add(new Packet11Message(name + " joined the game"));			  
	  }
	  catch(Exception e) {
	      System.err.println("Connection@" + port + " failed!");
	      e.printStackTrace();
	      disconnect = true;
	  }	  

	  network.sendMessage(name + " has joined the game.");
	  sendMessage("Welcome to " + network.name + "@" + network.engine.game.scenario.name);
	  sendMessage(network.motd);
	  
	  massSync();

	  hbLast = network.engine.getTime();
	  loading = false;
	  while(!disconnect) {
		  Object o = null;
		  Packet p;
		  try {
			  o = in.readObject();
		  }
		  catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  try {
			  if(o != null) {
				  p = (Packet) o;
				  if(p != null) {
						if(p.packetType() == 5)
							packet5(p);
						else if(p.packetType() == 2)
							packet2(p);
						else if(p.packetType() == 10)
							packet10(p);
						else if(p.packetType() == 50)
							packet50(p);
						else if(p.packetType() == 53)
							packet53(p);
						else 
							network.packetsIn.add(p);
				  }
			  }
		  }
		  catch (Exception e) {
				System.err.println("Bad packet from client threw exception: " + e.getClass().toString());
		  }
	  }
	}
	
	public void packet2(Packet p) {
		Packet2Disconnect d = (Packet2Disconnect) p;
		System.out.println(name + " disconnect: " + d.reason);
		disconnect(d.reason);
	}
	
	public void packet5(Packet p) {
		hbLast = network.engine.getTime();
	}
	
	public void packet10(Packet p) {
		Packet10Instantiate i = (Packet10Instantiate) p;
		if(i.simulated)
			i.port = port;
		network.packetsIn.add(i);
	}
	
	public void packet50(Packet p) {
		if(control != -1) {
			Actor a = network.engine.game.getActor(control);
			if(a != null)
				a.kill();
			control = -1;
		}
		Actor a = network.engine.game.spawnPlayer(port, name);
		controlPacket(a.nid);
	}
	
	public void packet53(Packet p) {
		Packet53Team t = (Packet53Team) p;
		team = t.team;
		if(control != -1) {
			Actor a = network.engine.game.getActor(control);
			if(a != null)
				a.kill();
			control = -1;
		}
		network.sendMessage(name + " has joined team " + team);
	}
	  
	//TODO: TEST THIS EXTENSIVELY! Synchronized so that the output stream doesnt get written to by multiple threads. Might be unstable.
	public synchronized void sendPacket(Packet p) {		  
		try {
			out.writeObject(p);
			out.flush();
		} catch (IOException e) {
			System.err.println("Failed to send packet to " + name + "@" + port);
		}
	  }
	
	public void controlPacket(int n) {
		if(control != -1) {
			Actor a = network.engine.game.getActor(control);
			if(a != null) {
				a.name = "null";
			}
		}
		sendPacket(new Packet20Control(n));
		control = n;
		Actor a = network.engine.game.getActor(control);
		if(a != null) {
			a.name = name;
			a.team = team;
		}
	}
	
	public void sendMessage(String s) {
		sendPacket(new Packet49Message(s));
	}
	
	public void massSync() {
		int i = 0;
		while(i < network.engine.game.actors.size()) {
			Actor a = network.engine.game.actors.get(i);
			sendPacket(new Packet10Instantiate(a.nid, a.file, a.location.x, a.location.y, a.location.z, a.velocity.x, a.velocity.y, a.velocity.z, a.rotation.x, a.rotation.y, a.rotation.z));
			i++;
		}
	}
	  
	public void disconnect(String s) {
		if(control != -1) {
			Actor a = network.engine.game.getActor(control);
			if(a != null)
				a.kill();
			control = -1;
		}
		network.sendMessage(name + " has left the game.");
    	System.out.println("Disconnect, " + s + " " + name + "@" + connection.getInetAddress().getHostName());
		try {
			out.writeObject(new Packet2Disconnect(name, "Disconnect, " + s));
			out.flush();
		} catch (IOException e) {
			System.err.println("Failed to send disconnect to client: " + name + "@" + port);
		}
		disconnect = true;
		try {
			out.close();
			in.close();
			connection.close();
		} catch (IOException e) {
			System.err.println("Failed to close connection!");
		}
		network.playerDisconnect(port);
	}
}
