package twelveengine.data;

public class Vertex {
	public double x;
	public double y;
	public double z;
	
	public String name = "";
	
	public Vertex(double a, double b, double c) {
		x = a;
		y = b;
		z = c;
	}
	
	public Vertex(double a, double b, double c, String n) {
		x = a;
		y = b;
		z = c;
		name = n;
	}
	
	public Vertex copy() {
		return new Vertex(x,y,z);
	}
}
